<?php
class Barcode
{
	
}